#
# Tkinter 3000 -- Widget Construction Kit
# $Id: __init__.py 1769 2004-04-09 10:10:46Z fredrik $
#
# compatibility layer.  new code should import WCK instead
# (or the appropriate driver)

import warnings
warnings.warn("the tk3 module is deprecated; please use WCK instead",
              DeprecationWarning)

from WCK.wckTkinter import *
from WCK.Utils import *
