#
# The Widget Construction Kit
# $Id: __init__.py 2941 2006-12-04 18:07:00Z fredrik $
#
# wck redirector
#

# full version number (used by the setup framework)
VERSION = "1.1.1/2006-12-04"

# don't export date to Python users
VERSION = VERSION.split("/")[0]

from wckTkinter import *
from Utils import *
